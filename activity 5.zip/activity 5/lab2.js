
function myfunction(){
    alert("the audio will start within seconds please wait...");
};

function button(){
    alert("you will be directed to sign in page");
};

function onkey(){
    alert("you pressed a number");
};